

#include <iostream>
using namespace std;

const int R = 5;
const int C = 5;

int sommaMatrice(int a[][C], int R, int C);
int mediaMatrice(int a[][C], int R, int C);
int maxMatrice(int a[][C], int R, int C);
int minMatrice(int a[][C], int R, int C);
void zeroMatrice(int a[][C], int R);
void stampaMatrice(int a[][C], int R, int C);

int main() {
    int a[R][C], somma = 0, min, max, media;

    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            cout << "Inserisci il numero alla riga " << i << " e alla colonna " << j << ": ";
            cin >> a[i][j];
        }
    }

    somma = sommaMatrice(a, R, C);
    media = mediaMatrice(a, R, C);
    min = minMatrice(a, R, C);
    max = maxMatrice(a, R, C);
    zeroMatrice(a, R);
    stampaMatrice(a, R, C);

    cout << "Somma: " << somma << endl;
    cout << "Media: " << media << endl;
    cout << "Minimo: " << min << endl;
    cout << "Massimo: " << max << endl;

    return 0;
}
int sommaMatrice(int a[][C], int R, int C) {
    int somma=0;
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            somma = somma + a[i][j];
        }
    }
    return somma;
}

int mediaMatrice(int a[][C], int R, int C) {
    
    return sommaMatrice(a, R, C)/(R * C);
}
int maxMatrice(int a[][C], int R, int C) {
    int max;
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            if (a[i][j] > max) {
                max = a[i][j];
            }
        }
    }
    return max;
}
int minMatrice(int a[][C], int R, int C) {
    int min;
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            if (a[i][j] < min) {
                min = a[i][j];
            }
        }
    }
    return min;
}
void stampaMatrice(int a[][C], int R, int C) {
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            cout << "Numero alla riga " << i << " e alla colonna " << j << ": " << a[i][j] << endl;
        }
    }
}

void zeroMatrice(int a[][C], int R) {
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            if (a[i][j] < 0) {
                a[i][j] = 0;
            }
        }
    }
}


