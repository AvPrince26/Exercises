
#include <iostream>

using namespace std;
void bubbleSort(int a[],int n);
void terzoVettore(int arr[],int a[],int ar[],int x,int n);
//main
int main()
{
    const int n=4;
    const int m=5;
    int x=n+m,a[n],ar[m],arr[n+m];
    
    	cout<<"Inserisci gli elementi:\n"; 
	for(int i=0;i<n;i++){
		cin>>a[i];
		arr[i]=a[i];
	}
	  	cout<<"Inserisci gli elementi:\n"; 
	for(int i=0;i<m;i++){
		cin>>ar[i];
		arr[i+n]=ar[i];
	}

bubbleSort(arr,x);
cout<<"Terzo Vettore ordinato: ";
	for(int i=0;i<x;i++){
	cout<<"\n"<<arr[i];
	}


 
    return 0;
}
//???
void terzoVettore(int arr[],int a[],int ar[],int x,int n){
	for(int i=0;i<x;i++){
	arr[i]=a[i];
	arr[i+n]=ar[i];
	}
    
}

//bubble sort
void bubbleSort(int a[], int n){
    int posizioneUltimoScambio=n;
	int ultimaposizione=n;
	int temp=0;
	bool scambio=true;
	//ordino gli elementi		
	while(scambio){
	    
	    
	   scambio=false; 
		for(int j=0;j<ultimaposizione-1;j++){
			if(a[j]>a[j+1] )
			{
			    scambio=true;
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
				posizioneUltimoScambio=j+1;
			}
			
		}
		ultimaposizione=posizioneUltimoScambio;
	}
	
}

