
#include <iostream>

using namespace std;
int binarySearch(int a[],int n,int x) {
 int med,ini=0,fin=n-1;

while (ini<=fin){
    med=(ini+fin)/2;
    if(a[med]==x){
        break;
    }
    if (x<a[med]){
        fin=med-1;
    }else {
        ini=med+1;
    }
    
}
if (ini>fin){
    cout<<"Valore non trovato";
    return -1;
    
}else {
    cout<<"Elemento trovato alla posizione "<<med;
    return 0;
}
 
}
int main()
{
    const int n=4;
    int x,searchRis,a[n];
    
    	cout<<"Inserisci gli elementi:\n"; 
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	cout<<"Inserisci il numero da trovare\n";
	cin>>x;

searchRis=binarySearch(a,n,x);
 
    return 0;
}

